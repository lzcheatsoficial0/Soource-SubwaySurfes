<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

if (!isset($_SESSION['id_usuario'])) {
    header("Location: /sing-in/index.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];
$sql = "SELECT saldo FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erro na preparação da consulta: " . $conn->error);
}

$stmt->bind_param("s", $id_usuario);
$stmt->execute();
$stmt->bind_result($saldo);

if ($stmt->fetch()) {
    // O saldo foi encontrado
} else {
    $saldo = 0.00;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Betting company Aviator - online sports betting</title>
    <link rel="shortcut icon" href="images/logo.png" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/pretty-checkbox.min.css">
    <link rel="stylesheet" href="css/niceCountryInput.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.ccpicker.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/toastr.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="css/responsive.dataTables.min.css">
</head>
<body class="dark-bg-main">
<header>
    <div class="header-top">
        <div class="header-left" onclick="window.location.href='/dashboard'">
            <img src="images/logo.png" class="logo1">
        </div>
        <div class="header-right d-flex align-items-center">
            <h1 class='register-btn rounded-pill d-flex align-items-center me-2 reg_btn'>R$ <?php echo number_format($saldo, 2, ',', '.'); ?></h1>
        </div>
    </div>
</header>
<div class="main-container" style="background-color: rgb(0, 35, 71);">
    <div class="collection-page d-none">
        <div class="owl-carousel owl-theme">
            <div class="item"><img src="images/01.jpg" class="w-100"></div>
            <div class="item"><img src="images/02.jpg" class="w-100"></div>
        </div>
        <div class="container" style="padding-bottom: 20px;">
                <div class="lz-container">
                    <div class="lz-item">
                        <a href="#" onclick="window.location.href='http://localhost:8080/subway.php'; return false;">
                <img src="iconeJogos/subway.png" alt="Betfiery Original">
            </a>
                    </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery.mCustomScrollbar.js"></script>
<script src="js/anime.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/main.js"></script>
<script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/65b70cdb0ff6374032c5ed0e/1hl9gkfbo';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
</script>
</body>
</html>
