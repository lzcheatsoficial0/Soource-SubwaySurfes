<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    logMessage("Falha na conexão com o banco de dados: " . $conn->connect_error);
    die("Erro na conexão com o banco de dados.");
}

if (!isset($_SESSION['id_usuario'])) {
    header("Location: /sing-in/index.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];
$sql = "SELECT saldo FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);

// Verificar se a preparação da consulta foi bem-sucedida
if ($stmt === false) {
    logMessage("Erro na preparação da consulta: " . $conn->error);
    die("Erro na preparação da consulta.");
}

$stmt->bind_param("s", $id_usuario);
$stmt->execute();

// Verificar se a execução da consulta foi bem-sucedida
if ($stmt->error) {
    logMessage("Erro na execução da consulta: " . $stmt->error);
    die("Erro na execução da consulta.");
}

$stmt->bind_result($saldo);

// Verificar se o fetch foi bem-sucedido
if ($stmt->fetch()) {
    // O saldo foi encontrado

    if ($saldo >= 5 && $typeGame == 'Loss') {
        // Depuração
        logMessage("Saldo antes da dedução: " . $saldo);

        // Deduzir 5 do saldo apenas se o saldo for suficiente e o tipo de jogo for 'Loss'
        $saldo -= 5;

        // Depuração
        logMessage("Saldo após a dedução: " . $saldo);

        // Atualizar o saldo no banco de dados
        $sql_update = "UPDATE usuarios SET saldo = ? WHERE id_usuario = ?";
        $stmt_update = $conn->prepare($sql_update);

        // Verificar se a preparação da atualização do saldo foi bem-sucedida
        if ($stmt_update === false) {
            logMessage("Erro na preparação da atualização do saldo: " . $conn->error);
            die("Erro na preparação da atualização do saldo.");
        }

        $stmt_update->bind_param("ds", $saldo, $id_usuario);
        $stmt_update->execute();

        // Verificar se a atualização foi bem-sucedida
        if ($stmt_update->error) {
            logMessage("Erro na atualização do saldo: " . $stmt_update->error);
            die("Erro na atualização do saldo.");
        }

        $stmt_update->close();
    }
} else {
    $saldo = 0.00;
}

$stmt->close();
$conn->close();

function logMessage($message) {
    // Abre o arquivo de log ou cria se não existir
    $logFile = fopen("logs.txt", "a");

    // Adiciona a mensagem de log ao arquivo
    fwrite($logFile, "[" . date("Y-m-d H:i:s") . "] " . $message . "\n");

    // Fecha o arquivo de log
    fclose($logFile);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script type="text/javascript">
    const aposta = 5; 
    const typeGame = 'Loss'; // 
</script>
    <meta charset="UTF-8">
    <meta http-equiv="content-type" content="text/html; charset=UTF8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no, minimal-ui, viewport-fit=cover" />
    <meta name="description" content="">
    <link rel="manifest" href="subwaysurfers.webmanifest">
    <link rel="icon" href="assets/images/app-icon-16.png" type="image/png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/app-icon-114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/app-icon-72.png">
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/app-icon-57.png">
    <link rel="apple-touch-icon-precomposed" href="assets/images/app-icon-57.png">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <meta name="robots" content="noindex,nofollow" />
    <title>Subway Surfers Web</title>
    <style>
        body, html {
            margin: 0;
            height: 100%;
            background-color: #0b316b;
            overflow: hidden;
            background-image: url('assets/preload/splash.png');
            background-repeat: no-repeat;
            background-position: center;
        }
        #message {
            text-align: center;
            font-size: 18px;
            z-index: 5;
            font-family: "Verdana", sans-serif;
            color: #fff;
            position: fixed;
            width: 100%;
            z-index: 9999;
            padding: 20px;
        }
        .dot {
            display: inline;
            margin-left: 0.2em;
            margin-right: 0.2em;
            position: relative;
            top: -1em;
            font-size: 3.5em;
            opacity: 0;
            animation: showHideDot 2.5s ease-in-out infinite;
        }
        .dot.one { animation-delay: 0.2s; }
        .dot.two { animation-delay: 0.4s; }
        .dot.three { animation-delay: 0.6s; }
        @keyframes showHideDot {
            0% { opacity: 0; }
            50% { opacity: 1; }
            60% { opacity: 1; }
            100% { opacity: 0; }
        }
        button#sair, button#meta {
            position: absolute;
            display: none;
            top: 20px;
            width: 190px;
            line-height: 32px;
            font-size: 16px;
            font-family: sans-serif;
            text-align: center;
            color: #fff;
            background-color: #2e1a07e8;
            box-shadow: 0 0 6px 0 #fff;
            border: .5px solid #120904;
            border-radius: 10px;
            z-index: 100000;
        }
        button#meta {
            top: 70px;
        }
        /* Add Toast Styling */
        #toast-container {
            position: fixed;
            z-index: 999999;
            margin-top: 22px;
            margin-bottom: 16px;
        }
        .toast {
            background: #090d1c;
            color: #fff;
            overflow: hidden;
            margin: 0 0 8px;
            padding: 15px;
            width: 300px;
            border-radius: 5px;
            border: none;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 18px 2px rgba(73,84,99,.25);
            position: relative;
        }
        .toast-message {
            position: relative;
            flex-grow: 1;
            font-size: 13px;
            line-height: 17px;
            display: flex;
            align-items: center;
            padding-left: 10px;
            min-height: 30px;
        }
        .toast-message-icon {
            display: inline-block;
            font-size: 14px;
            margin-right: 15px;
            margin-left: -10px;
            text-align: center;
            height: 30px;
            width: 30px;
            line-height: 30px;
            border-radius: 50%;
        }
        /* Adjust Toast Position */
        .toast-top-right {
            top: 90px;
            right: 20px;
            width: 300px;
        }
    </style>
</head>
<body>
    <button id="sair" style="display: none;" value="$id">ENCERRAR</button>
    <button id="meta" style="display: none;">META: R$5,00</button>
    <div id="message">
        <h1>Loading...</h1>
        <h1 class="dot one">.</h1><h1 class="dot two">.</h1><h1 class="dot three">.</h1>
    </div>
    <script>
        window.NOSW = false;
        window.GAME_CONFIG = {
            leaderboard: 'mockup',
            bundlesPath: './bundles',
        }
    </script>
    <script src="js/loading.js"></script>
    <script src="js/boot.js"></script>
    <script src="js/dependencies.bundle.js"></script>
    <!--<script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool@latest'></script>-->
</body>
</html>
