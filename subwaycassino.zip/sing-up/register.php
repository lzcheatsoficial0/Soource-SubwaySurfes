<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao servidor MySQL (substitua pelas suas próprias credenciais)
    $servername = "localhost";
    $username = "root";
    $password = "";

    $conn = new mysqli($servername, $username, $password);

    if ($conn->connect_error) {
        die("Falha na conexão com o servidor MySQL: " . $conn->connect_error);
    }

    // Nome do banco de dados
    $dbname = "users";

    // Verificar se o banco de dados existe, se não, criar
    $createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS $dbname";
    
    if ($conn->query($createDatabaseQuery) === TRUE) {
        // Conectar ao banco de dados
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Falha na conexão com o banco de dados '$dbname': " . $conn->connect_error);
        }

        // Nome da tabela
        $tablename = "usuarios";

        // Verificar se a tabela existe, se não, criar
        $createTableQuery = "CREATE TABLE IF NOT EXISTS $tablename (
            id_usuario VARCHAR(255) PRIMARY KEY,
            nome VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            senha VARCHAR(255) NOT NULL,
            saldo DECIMAL(10,2) NOT NULL
        )";
        
        if ($conn->query($createTableQuery) === TRUE) {
            // Restante do seu código para processar o registro
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirmPassword'];

            // Verificar se as senhas coincidem
            if ($password !== $confirmPassword) {
                echo "Senhas não coincidem.";
                exit();
            }

            // Gerar id_usuario aleatório
            $id_usuario = uniqid();

            // Definir saldo inicial como 0.00
            $saldo = 0.00;

            // Hash da senha (recomenda-se utilizar funções de hash seguras)
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Inserir dados no banco de dados
            $insertQuery = "INSERT INTO $tablename (id_usuario, nome, email, senha, saldo) VALUES ('$id_usuario', '$nome', '$email', '$hashedPassword', $saldo)";

            if ($conn->query($insertQuery) === TRUE) {
                // Criação de um array com a mensagem de sucesso
                $response = array(
                    'status' => 'success',
                    'message' => 'Registro bem-sucedido!'
                );

                // Enviar a resposta como JSON
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                // Criação de um array com a mensagem de erro
                $response = array(
                    'status' => 'error',
                    'message' => 'Erro no registro: ' . $conn->error
                );

                // Enviar a resposta como JSON
                header('Content-Type: application/json');
                echo json_encode($response);
            }

        } else {
            // Criação de um array com a mensagem de erro
            $response = array(
                'status' => 'error',
                'message' => 'Erro ao criar ou verificar a tabela ' . $tablename . ': ' . $conn->error
            );

            // Enviar a resposta como JSON
            header('Content-Type: application/json');
            echo json_encode($response);
        }

    } else {
        // Criação de um array com a mensagem de erro
        $response = array(
            'status' => 'error',
            'message' => 'Erro ao criar ou verificar o banco de dados ' . $dbname . ': ' . $conn->error
        );

        // Enviar a resposta como JSON
        header('Content-Type: application/json');
        echo json_encode($response);
    }

    $conn->close();
}
?>
