<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Página em Construção</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="javascripts/jquery.tipsy.js"></script>

    <script>
        $(function() {
            $('#tipsy').tipsy({fade: true, gravity: 's'});
        });
    </script>

    <!--[if lt IE 9]>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <![endif]-->
</head>
<body>
    <div class="wrapper">
        <div class="hr"></div>
        <h1>Desculpe, estamos passando por uma manutenção.</h1>
        <p>É rapidinho, estamos rodando alguns procedimentos de segurança para que seus dados não se percam.</p>

        <script>
            const start_date = new Date("March 28, 2014 11:50:00");
            const end_date = new Date("March 28, 2015 14:00:00");
            const start = start_date.getTime();
            const end = end_date.getTime();

            window.setInterval(function(){
                const now = +new Date;
                let restante = end - start;
                let porcentagem = (now - start) / (end - start) * 100;

                if (porcentagem > 100) {
                    porcentagem = 100;
                }

                if (porcentagem === 100) {
                    location.reload();
                }

                document.getElementById('tipsy').setAttribute('title', Math.round(porcentagem) + "% Completo.");
                porcentagem += "%";
                document.getElementById("progress-bar").style.width = porcentagem;
            }, 100);
        </script>

        <section class="progress">
            <div class="progress-bar-container" id="tipsy" title="99% Completo">
                <article id="progress-bar" class="progress-bar"></article>
            </div>
        </section>
    </div>
</body>
</html>
