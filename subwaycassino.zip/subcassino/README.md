Página de Manutenção
====================

Uma página em HTML e Javascript de manutenção...


Uma modificação dessa página: [página](http://medialoot.com/preview/coming-soon-template/)



Configuração
============

1. Abra o arquivo index.html
2. Procure pela ultima tag <code>&lt;script&gt;</code>
3. Modifique as variaveis start_date e end_date para as datas que você quiser.
4. Modifique seu logo e o title.

Pronto, você tem uma página pronta...
