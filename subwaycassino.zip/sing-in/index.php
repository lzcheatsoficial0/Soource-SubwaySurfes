<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Falha na conexão com o banco de dados: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $userPassword = $_POST['password'];

    $sql = "SELECT id_usuario, senha FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Erro na preparação da consulta: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($id_usuario, $hashedPassword);

    if ($stmt->fetch() && password_verify($userPassword, $hashedPassword)) {
        $_SESSION['id_usuario'] = $id_usuario;

        if (isset($_POST['remember'])) {
            $expire = time() + 30 * 24 * 3600; // 30 dias de expiração
            setcookie('remember_email', $email, $expire, '/');
            setcookie('remember_password', $userPassword, $expire, '/');
        } else {
            setcookie('remember_email', '', time() - 3600, '/');
            setcookie('remember_password', '', time() - 3600, '/');
        }

        header("Location: http://localhost:8080/index.php");
        exit();
    } else {
        echo "Senha incorreta ou usuário não encontrado.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <h2>Nox Igaming</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <input type="email" name="email" placeholder="Enter Email" required
                value="<?php echo isset($_COOKIE['remember_email']) ? $_COOKIE['remember_email'] : ''; ?>">
            <input type="password" name="password" placeholder="Enter Your Password" required
                value="<?php echo isset($_COOKIE['remember_password']) ? $_COOKIE['remember_password'] : ''; ?>">
            <input type="checkbox" name="remember" id="remember"
                <?php echo isset($_COOKIE['remember_email']) ? 'checked' : ''; ?>>
            <label for="remember">Remember Me</label>
            <button type="submit">Sign In</button>
            <a href="#">Forgot Password?</a>
        </form>
        <p>Don't have an account? <a href="../sing-up/index.html">Create account</a></p>
    </div>
</body>
</html>
