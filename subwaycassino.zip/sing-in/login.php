<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao servidor MySQL (substitua pelas suas próprias credenciais)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Falha na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Recuperar dados do formulário
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Consulta para verificar as credenciais
    $sql = "SELECT id_usuario, senha FROM usuarios WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row["senha"];

        // Verifica se a senha fornecida coincide com a senha no banco de dados
        if (password_verify($password, $hashedPassword)) {
            // Inicia a sessão antes de redirecionar
            session_start();
            $_SESSION['id_usuario'] = $row['id_usuario'];

            // Redireciona para a página principal
            header("Location: http://localhost:8080/sing-in/index.php");

            exit();
        } else {
            echo "Senha incorreta.";
        }
    } else {
        echo "Usuário não encontrado.";
    }

    $conn->close();
}
?>
